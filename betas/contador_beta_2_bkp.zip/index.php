<?php
        //Contador de visitas simples
        $texto_contador = "Número de visitas";
        $arquivo="contador.ctr";
        

        $default = "color: #f45c5c !important;font-family:serif;font-size: 0.6em;font-weight: 400;";
        $estilo_contador = $default;

        if (isset($_GET['tema'])){
                $estilo_contador = $_GET['tema'];
        }
        switch($estilo_contador){
                case 'black':
                $estilo_contador = "border-bottom-color:#f45c5c; color: black !important;font-family:serif;font-size: 0.6em;font-weight: 400;text-transform: uppercase;";
                break;

                case 'red':
                $estilo_contador = "border-bottom-color:#f45c5c; color: #f45c5c !important;font-family:serif;font-size: 0.6em;font-weight: 400;text-transform: uppercase;";
                break;

                default:
                $estilo_contador = $default;
                break;
        }
        if (isset($_GET['texto'])){
                $texto_contador = $_GET['texto'];
        }

        if (isset($_GET['limpar'])){
                $fp = fopen($arquivo, "w");
                fwrite($fp, 0);
                fclose($fp);
        }else{
                $fp = fopen($arquivo, "r");
                $count = fread($fp, 1024);
                fclose($fp);
                $count = $count + 1;
                echo "<span style='$estilo_contador'>$texto_contador: " . $count . "</span>";
                $fp = fopen($arquivo, "w");
                fwrite($fp, $count);
                fclose($fp);
        }       
         
        if (isset($_GET['valor'])){
                $count = $_GET['valor'] -1;
                $fp = fopen($arquivo, "w");
                fwrite($fp, $count);
                fclose($fp);
        }
?>

